"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  FaFileAlt,
  FaFilePdf,
  FaFileExcel,
  FaCalendarAlt,
  FaMoneyBillWave,
  FaChartLine,
  FaUsers,
  FaCheckCircle,
  FaArrowUp,
  FaArrowDown,
} from "react-icons/fa";
import FeesNav from "../components/FeesNav";

const MONTHLY_DATA = [
  { month: "May", amount: 280000, target: 300000 },
  { month: "Jun", amount: 320000, target: 310000 },
  { month: "Jul", amount: 390000, target: 350000 },
  { month: "Aug", amount: 360000, target: 370000 },
  { month: "Sep", amount: 410000, target: 400000 },
  { month: "Oct (MTD)", amount: 384000, target: 420000 },
];

const BATCH_BREAKDOWN = [
  {
    batch: "Full Stack Web Dev (Batch A)",
    students: 48,
    billed: 1680000,
    collected: 1512000,
    pending: 168000,
    rate: 90,
  },
  {
    batch: "Data Science & AI (Morning)",
    students: 52,
    billed: 2080000,
    collected: 1872000,
    pending: 208000,
    rate: 90,
  },
  {
    batch: "Python Masterclass (Evening)",
    students: 36,
    billed: 900000,
    collected: 765000,
    pending: 135000,
    rate: 85,
  },
  {
    batch: "UI/UX Design Studio",
    students: 30,
    billed: 840000,
    collected: 756000,
    pending: 84000,
    rate: 90,
  },
  {
    batch: "Foundation Cohort",
    students: 18,
    billed: 324000,
    collected: 298000,
    pending: 26000,
    rate: 92,
  },
];

export default function ReportsClient() {
  const [timeframe, setTimeframe] = useState("month");

  return (
    <div className="w-full min-w-0">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6 px-1 sm:px-6 lg:px-8 w-full min-w-0">
        <FeesNav />

        {/* Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-r from-[#D6451B] to-orange-500 p-4 sm:p-6 lg:p-8 text-white shadow-lg w-full min-w-0"
        >
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between min-w-0">
            <div className="min-w-0 flex-1">
              <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider">
                Financial Intelligence
              </span>

              <h1 className="mt-3 text-2xl font-extrabold sm:text-3xl lg:text-4xl">
                Financial Reports & Audit
              </h1>

              <p className="mt-2 text-xs sm:text-sm lg:text-base max-w-2xl text-orange-100 leading-relaxed font-normal">
                Analyze revenue collections, cash-flow velocity, recovery rates, and batch profitability metrics.
              </p>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                onClick={() => alert("Downloading PDF financial statement...")}
                className="flex items-center gap-2 rounded-xl bg-white px-4 py-3 text-xs sm:text-sm font-bold text-[#D6451B] shadow-xs hover:bg-orange-50 transition"
              >
                <FaFilePdf className="text-xs" />
                <span>PDF Report</span>
              </button>
              <button
                onClick={() => alert("Exporting Excel financial ledger...")}
                className="flex items-center gap-2 rounded-xl border border-white/30 bg-white/10 px-4 py-3 text-xs sm:text-sm font-bold text-white hover:bg-white/20 transition"
              >
                <FaFileExcel className="text-xs" />
                <span>Export Excel</span>
              </button>
            </div>
          </div>
        </motion.section>

        {/* Timeframe Selector Bar */}
        <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-3 sm:p-4 shadow-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            {[
              { id: "month", label: "This Month (Oct 2026)" },
              { id: "quarter", label: "Q3 2026" },
              { id: "half", label: "Last 6 Months" },
              { id: "fy", label: "FY 2026-27" },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTimeframe(t.id)}
                className={`rounded-xl px-3.5 py-2 text-xs font-bold transition shrink-0 ${
                  timeframe === t.id
                    ? "bg-[#D6451B] text-white shadow-xs"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
          <span className="hidden sm:inline-block text-xs font-semibold text-slate-400">
            Updated today at 05:00 PM
          </span>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-2.5 sm:gap-4 lg:grid-cols-4 w-full min-w-0">
          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Gross Billed</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-slate-900">
              ₹58,24,000
            </h3>
            <div className="mt-1 flex items-center gap-1 text-[11px] font-bold text-emerald-600">
              <FaArrowUp />
              <span>+14% vs last period</span>
            </div>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Total Collected</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-emerald-600">
              ₹52,03,000
            </h3>
            <div className="mt-1 flex items-center gap-1 text-[11px] font-bold text-emerald-600">
              <FaArrowUp />
              <span>89.3% realization</span>
            </div>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Total Outstanding</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-rose-600">
              ₹6,21,000
            </h3>
            <div className="mt-1 flex items-center gap-1 text-[11px] font-bold text-rose-600">
              <FaArrowDown />
              <span>-6% reduction in dues</span>
            </div>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Active Students</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-[#D6451B]">
              184
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Across 5 cohorts</p>
          </div>
        </div>

        {/* Charts & Breakdown */}
        <div className="grid gap-4 sm:gap-6 lg:grid-cols-3 w-full min-w-0">
          {/* Monthly Collection Bars */}
          <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 shadow-xs">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Monthly Revenue Realization
                </h3>
                <p className="text-xs text-slate-500">
                  Actual collections vs projected billing targets
                </p>
              </div>
              <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
                FY 2026
              </span>
            </div>

            <div className="mt-6 space-y-4">
              {MONTHLY_DATA.map((item) => (
                <div key={item.month} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-700">{item.month}</span>
                    <span className="text-emerald-600">
                      ₹{(item.amount / 1000).toFixed(0)}k{" "}
                      <span className="text-slate-400 font-normal">
                        / ₹{(item.target / 1000).toFixed(0)}k target
                      </span>
                    </span>
                  </div>
                  <div className="h-3 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      style={{
                        width: `${Math.min(
                          100,
                          Math.round((item.amount / item.target) * 100)
                        )}%`,
                      }}
                      className="h-full rounded-full bg-gradient-to-r from-[#D6451B] to-emerald-500"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Method Distribution */}
          <div className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="pb-4 border-b border-slate-100">
                <h3 className="text-base font-bold text-slate-900">
                  Payment Channels
                </h3>
                <p className="text-xs text-slate-500">
                  Collection breakdown by mode
                </p>
              </div>

              <div className="mt-6 space-y-4">
                {[
                  { mode: "UPI / QR Code", share: 74, color: "bg-emerald-500" },
                  { mode: "Cash Counter", share: 16, color: "bg-[#D6451B]" },
                  { mode: "Debit / Credit Cards", share: 7, color: "bg-blue-500" },
                  { mode: "Net Banking (NEFT/IMPS)", share: 3, color: "bg-purple-500" },
                ].map((channel) => (
                  <div key={channel.mode} className="space-y-1">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="text-slate-700">{channel.mode}</span>
                      <span className="text-slate-900">{channel.share}%</span>
                    </div>
                    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
                      <div
                        style={{ width: `${channel.share}%` }}
                        className={`h-full rounded-full ${channel.color}`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 rounded-xl bg-orange-50/60 p-3 text-xs text-[#D6451B] font-medium text-center">
              💡 90% of students prefer instant UPI digital payments.
            </div>
          </div>
        </div>

        {/* Batch-wise Financial Ledger */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-xs overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 sm:px-6 py-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Cohort Profitability & Ledger
              </h3>
              <p className="text-xs text-slate-500">
                Batch-level revenue performance and outstanding balances
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 uppercase font-semibold">
                <tr>
                  <th className="px-6 py-3.5">Cohort Batch</th>
                  <th className="px-4 py-3.5">Enrolled</th>
                  <th className="px-4 py-3.5">Total Billed</th>
                  <th className="px-4 py-3.5">Collected</th>
                  <th className="px-4 py-3.5">Pending Dues</th>
                  <th className="px-6 py-3.5 text-right">Recovery Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {BATCH_BREAKDOWN.map((b) => (
                  <tr key={b.batch} className="hover:bg-orange-50/40 transition">
                    <td className="px-6 py-4 font-bold text-slate-900">
                      {b.batch}
                    </td>
                    <td className="px-4 py-4 text-slate-600">
                      {b.students} students
                    </td>
                    <td className="px-4 py-4 text-slate-800">
                      ₹{b.billed.toLocaleString("en-IN")}
                    </td>
                    <td className="px-4 py-4 font-bold text-emerald-600">
                      ₹{b.collected.toLocaleString("en-IN")}
                    </td>
                    <td className="px-4 py-4 font-bold text-rose-600">
                      ₹{b.pending.toLocaleString("en-IN")}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="inline-block rounded-full bg-emerald-100 px-2.5 py-1 text-xs font-extrabold text-emerald-700">
                        {b.rate}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
