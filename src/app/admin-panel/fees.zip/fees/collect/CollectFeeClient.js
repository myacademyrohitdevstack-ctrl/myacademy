"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FaCashRegister,
  FaUserGraduate,
  FaWallet,
  FaPhoneAlt,
  FaEnvelope,
  FaCalendarAlt,
  FaCheckCircle,
  FaPrint,
  FaReceipt,
  FaTimes,
  FaUniversity,
  FaCreditCard,
  FaMoneyBillWave,
  FaQrcode,
} from "react-icons/fa";
import FeesNav from "../components/FeesNav";

const MOCK_STUDENTS = [
  {
    _id: "std-001",
    name: "Aarav Sharma",
    rollNo: "IMA-2026-001",
    email: "aarav.sharma@example.com",
    phone: "+91 98765 43210",
    batch: "Full Stack Web Development (Batch A)",
    totalFee: 35000,
    paidAmount: 22500,
    pendingAmount: 12500,
    dueDate: "2026-10-25",
  },
  {
    _id: "std-002",
    name: "Priya Patel",
    rollNo: "IMA-2026-002",
    email: "priya.patel@example.com",
    phone: "+91 98123 45678",
    batch: "Data Science & AI (Morning)",
    totalFee: 40000,
    paidAmount: 32000,
    pendingAmount: 8000,
    dueDate: "2026-10-28",
  },
  {
    _id: "std-003",
    name: "Rohan Mehta",
    rollNo: "IMA-2026-003",
    email: "rohan.mehta@example.com",
    phone: "+91 97654 32109",
    batch: "Python Masterclass (Evening)",
    totalFee: 25000,
    paidAmount: 10000,
    pendingAmount: 15000,
    dueDate: "2026-10-22",
  },
  {
    _id: "std-004",
    name: "Ananya Singh",
    rollNo: "IMA-2026-004",
    email: "ananya.singh@example.com",
    phone: "+91 96543 21098",
    batch: "UI/UX Design Studio",
    totalFee: 28000,
    paidAmount: 21500,
    pendingAmount: 6500,
    dueDate: "2026-10-30",
  },
  {
    _id: "std-005",
    name: "Devansh Nair",
    rollNo: "IMA-2026-005",
    email: "devansh.nair@example.com",
    phone: "+91 95432 10987",
    batch: "Spoken English & Communication",
    totalFee: 18000,
    paidAmount: 9000,
    pendingAmount: 9000,
    dueDate: "2026-11-05",
  },
];

export default function CollectFeeClient({ studentId }) {
  const initialStudent =
    MOCK_STUDENTS.find((s) => s._id === studentId) || MOCK_STUDENTS[0];

  const [selectedStudent, setSelectedStudent] = useState(initialStudent);
  const [amount, setAmount] = useState(selectedStudent.pendingAmount);
  const [paymentMode, setPaymentMode] = useState("UPI");
  const [refNumber, setRefNumber] = useState(
    `UPI-${Math.floor(100000 + Math.random() * 900000)}`
  );
  const [discount, setDiscount] = useState(0);
  const [paymentDate, setPaymentDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [remarks, setRemarks] = useState("Tuition installment payment");
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [generatedReceipt, setGeneratedReceipt] = useState(null);

  const handleStudentChange = (id) => {
    const s = MOCK_STUDENTS.find((item) => item._id === id);
    if (s) {
      setSelectedStudent(s);
      setAmount(s.pendingAmount);
      setDiscount(0);
    }
  };

  const handleCollect = (e) => {
    e.preventDefault();
    const finalAmount = Math.max(0, Number(amount) - Number(discount));
    const receipt = {
      receiptNo: `REC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      date: paymentDate,
      studentName: selectedStudent.name,
      rollNo: selectedStudent.rollNo,
      batch: selectedStudent.batch,
      amount: finalAmount,
      mode: paymentMode,
      refNumber: refNumber,
      discount: Number(discount),
      remarks: remarks,
      remainingPending: Math.max(0, selectedStudent.pendingAmount - finalAmount),
    };
    setGeneratedReceipt(receipt);
    setReceiptOpen(true);
  };

  return (
    <div className="w-full min-w-0">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6 px-1 sm:px-6 lg:px-8 w-full min-w-0">
        <FeesNav />

        {/* Hero */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-r from-[#D6451B] to-orange-500 p-4 sm:p-6 lg:p-8 text-white shadow-lg w-full min-w-0"
        >
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between min-w-0">
            <div className="min-w-0 flex-1">
              <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider">
                Fee Collection Terminal
              </span>

              <h1 className="mt-3 text-2xl font-extrabold sm:text-3xl lg:text-4xl">
                Collect Student Fee
              </h1>

              <p className="mt-2 text-xs sm:text-sm lg:text-base max-w-2xl text-orange-100 leading-relaxed font-normal">
                Record student tuition payments across cash, UPI, cards, and bank transfers with instant official invoice receipt generation.
              </p>
            </div>

            <div className="rounded-2xl border border-white/20 bg-white/10 p-4 sm:p-5 backdrop-blur-md shrink-0 lg:w-72">
              <div className="flex items-center justify-between">
                <p className="text-xs text-orange-100 font-semibold uppercase tracking-wider">
                  Pending Dues
                </p>
                <FaWallet className="text-white/80" />
              </div>
              <h2 className="mt-2 text-2xl sm:text-4xl font-extrabold">
                ₹{selectedStudent.pendingAmount.toLocaleString("en-IN")}
              </h2>
              <p className="mt-1 text-xs text-orange-100">
                Next due: {selectedStudent.dueDate}
              </p>
            </div>
          </div>
        </motion.section>

        {/* Form and Student Details Grid */}
        <div className="grid gap-4 sm:gap-6 lg:grid-cols-3 w-full min-w-0">
          {/* Left Column: Student Details Card */}
          <div className="lg:col-span-1 space-y-4 sm:space-y-6">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 shadow-xs">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">
                Select Student
              </h3>
              <div className="mt-3">
                <select
                  value={selectedStudent._id}
                  onChange={(e) => handleStudentChange(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-bold text-slate-800 outline-none focus:border-[#D6451B] bg-slate-50"
                >
                  {MOCK_STUDENTS.map((s) => (
                    <option key={s._id} value={s._id}>
                      {s.name} ({s.rollNo}) - Pending: ₹{s.pendingAmount}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mt-6 flex items-center gap-3.5 pb-4 border-b border-slate-100">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-100 text-lg font-bold text-[#D6451B]">
                  {selectedStudent.name.charAt(0)}
                </div>
                <div className="min-w-0 flex-1">
                  <h4 className="text-base font-bold text-slate-900 truncate">
                    {selectedStudent.name}
                  </h4>
                  <p className="text-xs text-slate-500 truncate">
                    Roll No: {selectedStudent.rollNo}
                  </p>
                  <span className="mt-1 inline-block rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                    Active Cohort
                  </span>
                </div>
              </div>

              <div className="mt-4 space-y-3 text-xs">
                <div className="flex items-center gap-2 text-slate-600">
                  <FaPhoneAlt className="text-slate-400 shrink-0" />
                  <span className="truncate">{selectedStudent.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600">
                  <FaEnvelope className="text-slate-400 shrink-0" />
                  <span className="truncate">{selectedStudent.email}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600">
                  <FaCalendarAlt className="text-slate-400 shrink-0" />
                  <span className="truncate">Due: {selectedStudent.dueDate}</span>
                </div>
              </div>

              {/* Fee Progress Breakdown */}
              <div className="mt-6 pt-4 border-t border-slate-100 space-y-2.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500 font-medium">Total Batch Fee</span>
                  <span className="font-bold text-slate-900">
                    ₹{selectedStudent.totalFee.toLocaleString("en-IN")}
                  </span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500 font-medium">Already Paid</span>
                  <span className="font-bold text-emerald-600">
                    ₹{selectedStudent.paidAmount.toLocaleString("en-IN")}
                  </span>
                </div>
                <div className="flex justify-between text-xs font-bold border-t border-slate-100 pt-2">
                  <span className="text-rose-600">Current Outstanding</span>
                  <span className="text-rose-600">
                    ₹{selectedStudent.pendingAmount.toLocaleString("en-IN")}
                  </span>
                </div>
                <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    style={{
                      width: `${Math.round(
                        (selectedStudent.paidAmount / selectedStudent.totalFee) * 100
                      )}%`,
                    }}
                    className="h-full rounded-full bg-gradient-to-r from-[#D6451B] to-emerald-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Payment Collection Form */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 lg:p-8 shadow-xs">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900">
                    Payment Details
                  </h3>
                  <p className="text-xs text-slate-500">
                    Enter transaction information and submit to update ledger
                  </p>
                </div>
                <span className="rounded-full bg-orange-100 px-3 py-1 text-xs font-bold text-[#D6451B]">
                  Batch: {selectedStudent.batch.split(" ")[0]}
                </span>
              </div>

              <form onSubmit={handleCollect} className="mt-6 space-y-4 sm:space-y-5">
                {/* Amount to collect & Discount */}
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Amount to Collect (₹) *
                    </label>
                    <div className="mt-1.5 relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                        ₹
                      </span>
                      <input
                        type="number"
                        min="1"
                        max={selectedStudent.pendingAmount}
                        value={amount}
                        onChange={(e) => setAmount(Number(e.target.value))}
                        required
                        className="w-full rounded-xl border border-slate-200 py-3 pl-8 pr-4 text-sm font-bold text-slate-900 outline-none focus:border-[#D6451B]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Scholarship / Discount (₹)
                    </label>
                    <div className="mt-1.5 relative">
                      <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                        ₹
                      </span>
                      <input
                        type="number"
                        min="0"
                        value={discount}
                        onChange={(e) => setDiscount(Number(e.target.value))}
                        className="w-full rounded-xl border border-slate-200 py-3 pl-8 pr-4 text-sm font-bold text-slate-900 outline-none focus:border-[#D6451B]"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Mode Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                    Payment Method *
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {[
                      { mode: "UPI", icon: FaQrcode },
                      { mode: "Cash", icon: FaMoneyBillWave },
                      { mode: "Card", icon: FaCreditCard },
                      { mode: "Net Banking", icon: FaUniversity },
                    ].map((item) => {
                      const Icon = item.icon;
                      const selected = paymentMode === item.mode;
                      return (
                        <button
                          key={item.mode}
                          type="button"
                          onClick={() => {
                            setPaymentMode(item.mode);
                            if (item.mode === "UPI") {
                              setRefNumber(
                                `UPI-${Math.floor(100000 + Math.random() * 900000)}`
                              );
                            } else if (item.mode === "Card") {
                              setRefNumber(
                                `CARD-${Math.floor(100000 + Math.random() * 900000)}`
                              );
                            } else if (item.mode === "Cash") {
                              setRefNumber("CASH-COUNTER");
                            } else {
                              setRefNumber(
                                `NEFT-${Math.floor(100000 + Math.random() * 900000)}`
                              );
                            }
                          }}
                          className={`flex items-center justify-center gap-2 rounded-xl p-3 text-xs font-bold border transition ${
                            selected
                              ? "border-[#D6451B] bg-orange-50 text-[#D6451B] shadow-xs"
                              : "border-slate-200 hover:bg-slate-50 text-slate-700"
                          }`}
                        >
                          <Icon className="text-sm" />
                          <span>{item.mode}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Reference ID & Date */}
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Transaction / Reference ID
                    </label>
                    <input
                      type="text"
                      value={refNumber}
                      onChange={(e) => setRefNumber(e.target.value)}
                      placeholder="e.g. UPI-984214, Cheque #5501"
                      className="mt-1.5 w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-medium text-slate-900 outline-none focus:border-[#D6451B]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Payment Date
                    </label>
                    <input
                      type="date"
                      value={paymentDate}
                      onChange={(e) => setPaymentDate(e.target.value)}
                      className="mt-1.5 w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-medium text-slate-900 outline-none focus:border-[#D6451B]"
                    />
                  </div>
                </div>

                {/* Remarks */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Remarks / Internal Note
                  </label>
                  <input
                    type="text"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="e.g. Month installment paid by father"
                    className="mt-1.5 w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-medium text-slate-900 outline-none focus:border-[#D6451B]"
                  />
                </div>

                {/* Net Summary Bar */}
                <div className="rounded-xl bg-orange-50/80 border border-orange-100 p-4 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-bold text-slate-700">
                      Net Amount to Collect
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Includes discount deduction
                    </p>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-[#D6451B]">
                    ₹{Math.max(0, Number(amount) - Number(discount)).toLocaleString(
                      "en-IN"
                    )}
                  </h3>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-2">
                  <button
                    type="submit"
                    className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#D6451B] to-orange-500 py-3.5 text-xs sm:text-sm font-bold text-white shadow-md hover:from-[#b93814] hover:to-orange-600 transition"
                  >
                    <FaCheckCircle />
                    <span>Record Payment & Generate Official Receipt</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* Printable Official Receipt Modal */}
        <AnimatePresence>
          {receiptOpen && generatedReceipt && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full max-w-lg rounded-2xl sm:rounded-3xl bg-white p-5 sm:p-7 shadow-2xl border border-slate-200"
              >
                {/* Receipt Header */}
                <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#D6451B] to-orange-500 text-white font-extrabold shadow-xs">
                      MA
                    </div>
                    <div>
                      <h3 className="font-extrabold text-base text-slate-900">
                        MyAcademy
                      </h3>
                      <p className="text-[10px] font-bold tracking-wider text-[#D6451B] uppercase">
                        Official Fee Receipt
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setReceiptOpen(false)}
                    className="rounded-xl p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                  >
                    <FaTimes />
                  </button>
                </div>

                {/* Receipt Details Box */}
                <div className="mt-5 space-y-3 rounded-xl bg-slate-50 p-4 border border-slate-100 text-xs">
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Receipt No:</span>
                    <strong className="font-bold text-slate-900">
                      {generatedReceipt.receiptNo}
                    </strong>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Payment Date:</span>
                    <span className="font-semibold text-slate-800">
                      {generatedReceipt.date}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Student Name:</span>
                    <strong className="font-bold text-slate-900">
                      {generatedReceipt.studentName} ({generatedReceipt.rollNo})
                    </strong>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Batch Cohort:</span>
                    <span className="font-medium text-slate-700">
                      {generatedReceipt.batch}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Payment Mode:</span>
                    <span className="font-bold text-slate-800">
                      {generatedReceipt.mode} ({generatedReceipt.refNumber})
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Remarks:</span>
                    <span className="font-medium text-slate-700">
                      {generatedReceipt.remarks}
                    </span>
                  </div>
                  <div className="flex justify-between pt-1 text-sm font-extrabold">
                    <span className="text-slate-900">Amount Paid:</span>
                    <span className="text-emerald-600 text-base">
                      ₹{generatedReceipt.amount.toLocaleString("en-IN")}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs font-semibold text-rose-600">
                    <span>Remaining Balance:</span>
                    <span>
                      ₹{generatedReceipt.remainingPending.toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>

                {/* Footer Notice */}
                <p className="mt-4 text-center text-[10px] text-slate-400">
                  This is a computer-generated fee acknowledgement receipt issued by MyAcademy.
                </p>

                {/* Receipt Actions */}
                <div className="mt-5 flex gap-2.5">
                  <button
                    onClick={() => window.print()}
                    className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-slate-900 py-3 text-xs sm:text-sm font-bold text-white hover:bg-slate-800 transition"
                  >
                    <FaPrint />
                    <span>Print Receipt</span>
                  </button>
                  <button
                    onClick={() => setReceiptOpen(false)}
                    className="flex items-center justify-center px-4 rounded-xl border border-slate-200 text-xs sm:text-sm font-bold text-slate-700 hover:bg-slate-50 transition"
                  >
                    Close
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
