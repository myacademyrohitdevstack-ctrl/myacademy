"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import {
  FaClock,
  FaSearch,
  FaFilter,
  FaWhatsapp,
  FaCashRegister,
  FaFileExport,
  FaExclamationCircle,
  FaCheckCircle,
  FaPhoneAlt,
  FaUserGraduate,
} from "react-icons/fa";
import FeesNav from "../components/FeesNav";

const INITIAL_PENDING = [
  {
    _id: "std-001",
    name: "Aarav Sharma",
    rollNo: "IMA-2026-001",
    batch: "Full Stack Web Dev (Batch A)",
    totalFee: 35000,
    paidAmount: 22500,
    pending: 12500,
    dueDate: "2026-10-18",
    overdueDays: 14,
    phone: "+91 98765 43210",
    status: "critical",
  },
  {
    _id: "std-002",
    name: "Priya Patel",
    rollNo: "IMA-2026-002",
    batch: "Data Science & AI (Morning)",
    totalFee: 40000,
    paidAmount: 32000,
    pending: 8000,
    dueDate: "2026-10-15",
    overdueDays: 17,
    phone: "+91 98123 45678",
    status: "critical",
  },
  {
    _id: "std-003",
    name: "Rohan Mehta",
    rollNo: "IMA-2026-003",
    batch: "Python Masterclass (Evening)",
    totalFee: 25000,
    paidAmount: 10000,
    pending: 15000,
    dueDate: "2026-10-22",
    overdueDays: 10,
    phone: "+91 97654 32109",
    status: "moderate",
  },
  {
    _id: "std-004",
    name: "Ananya Singh",
    rollNo: "IMA-2026-004",
    batch: "UI/UX Design Studio",
    totalFee: 28000,
    paidAmount: 21500,
    pending: 6500,
    dueDate: "2026-10-30",
    overdueDays: 2,
    phone: "+91 96543 21098",
    status: "upcoming",
  },
  {
    _id: "std-005",
    name: "Devansh Nair",
    rollNo: "IMA-2026-005",
    batch: "Full Stack Web Dev (Batch A)",
    totalFee: 35000,
    paidAmount: 17500,
    pending: 17500,
    dueDate: "2026-10-12",
    overdueDays: 20,
    phone: "+91 95432 10987",
    status: "critical",
  },
  {
    _id: "std-006",
    name: "Tanvi Deshmukh",
    rollNo: "IMA-2026-006",
    batch: "Data Science & AI (Morning)",
    totalFee: 40000,
    paidAmount: 30000,
    pending: 10000,
    dueDate: "2026-11-02",
    overdueDays: 0,
    phone: "+91 94321 09876",
    status: "upcoming",
  },
];

export default function PendingFeesClient() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBatch, setSelectedBatch] = useState("all");
  const [activeTab, setActiveTab] = useState("all"); // 'all', 'critical', 'upcoming'
  const [reminderToast, setReminderToast] = useState(null);

  const batchesList = [
    "all",
    "Full Stack Web Dev (Batch A)",
    "Data Science & AI (Morning)",
    "Python Masterclass (Evening)",
    "UI/UX Design Studio",
  ];

  const filteredStudents = INITIAL_PENDING.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.phone.includes(searchTerm);

    const matchesBatch =
      selectedBatch === "all" || student.batch === selectedBatch;

    const matchesTab =
      activeTab === "all"
        ? true
        : activeTab === "critical"
        ? student.status === "critical"
        : student.status === "upcoming" || student.status === "moderate";

    return matchesSearch && matchesBatch && matchesTab;
  });

  const totalOutstanding = filteredStudents.reduce((sum, s) => sum + s.pending, 0);

  const handleSendReminder = (student) => {
    const message = `Hello ${student.name}, this is a gentle fee reminder from MyAcademy. Your pending fee balance of ₹${student.pending.toLocaleString("en-IN")} for batch ${student.batch} was due on ${student.dueDate}. Kindly clear the outstanding at the earliest.`;
    const encoded = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${student.phone.replace(/[^0-9]/g, "")}?text=${encoded}`;
    window.open(whatsappUrl, "_blank");

    setReminderToast(`WhatsApp reminder dispatched to ${student.name}!`);
    setTimeout(() => setReminderToast(null), 4000);
  };

  return (
    <div className="w-full min-w-0">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6 px-1 sm:px-6 lg:px-8 w-full min-w-0">
        <FeesNav />

        {/* Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-r from-[#D6451B] to-orange-500 p-4 sm:p-6 lg:p-8 text-white shadow-lg w-full min-w-0"
        >
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between min-w-0">
            <div className="min-w-0 flex-1">
              <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider">
                Accounts Receivable
              </span>

              <h1 className="mt-3 text-2xl font-extrabold sm:text-3xl lg:text-4xl">
                Pending Fees & Dues
              </h1>

              <p className="mt-2 text-xs sm:text-sm lg:text-base max-w-2xl text-orange-100 leading-relaxed font-normal">
                Monitor student overdue balances across batches, dispatch automated WhatsApp reminders, and settle collections.
              </p>
            </div>

            <div className="rounded-2xl border border-white/20 bg-white/10 p-4 sm:p-5 backdrop-blur-md shrink-0 lg:w-72">
              <p className="text-xs text-orange-100 font-semibold uppercase tracking-wider">
                Filtered Outstanding
              </p>
              <h2 className="mt-2 text-2xl sm:text-4xl font-extrabold">
                ₹{totalOutstanding.toLocaleString("en-IN")}
              </h2>
              <p className="mt-1 text-xs text-orange-100">
                {filteredStudents.length} student accounts shown
              </p>
            </div>
          </div>
        </motion.section>

        {/* Toast Notification */}
        {reminderToast && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-xl bg-emerald-50 border border-emerald-200 p-3.5 flex items-center justify-between text-xs sm:text-sm font-bold text-emerald-800"
          >
            <div className="flex items-center gap-2">
              <FaCheckCircle className="text-emerald-600 text-base" />
              <span>{reminderToast}</span>
            </div>
            <button
              onClick={() => setReminderToast(null)}
              className="text-emerald-700 hover:text-emerald-900"
            >
              ✕
            </button>
          </motion.div>
        )}

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-2.5 sm:gap-4 lg:grid-cols-4 w-full min-w-0">
          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Total Unpaid Students</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-slate-900">
              {INITIAL_PENDING.length}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Across all batches</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-rose-600">Critical Overdue (&gt;10d)</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-rose-600">
              {INITIAL_PENDING.filter((s) => s.status === "critical").length}
            </h3>
            <p className="text-[11px] text-rose-500 mt-0.5">Immediate action required</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-amber-600">Due This Week</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-amber-600">
              {INITIAL_PENDING.filter((s) => s.status === "upcoming").length}
            </h3>
            <p className="text-[11px] text-amber-500 mt-0.5">Follow up scheduled</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-emerald-600">Avg Pending / Student</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-slate-900">
              ₹{(
                INITIAL_PENDING.reduce((sum, s) => sum + s.pending, 0) /
                INITIAL_PENDING.length
              ).toFixed(0)}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Per delinquent cohort</p>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs space-y-3">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            {/* Search Box */}
            <div className="relative flex-1 min-w-0">
              <FaSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs" />
              <input
                type="text"
                placeholder="Search by student name, roll number, or phone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-xs sm:text-sm font-medium text-slate-900 outline-none focus:border-[#D6451B]"
              />
            </div>

            {/* Batch Filter Dropdown */}
            <div className="flex items-center gap-2 shrink-0">
              <select
                value={selectedBatch}
                onChange={(e) => setSelectedBatch(e.target.value)}
                className="rounded-xl border border-slate-200 px-3 py-2.5 text-xs sm:text-sm font-bold text-slate-700 outline-none focus:border-[#D6451B] bg-slate-50"
              >
                {batchesList.map((batch) => (
                  <option key={batch} value={batch}>
                    {batch === "all" ? "All Batches" : batch}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Sub Tabs */}
          <div className="flex items-center gap-2 pt-2 border-t border-slate-100 overflow-x-auto scrollbar-none">
            <button
              onClick={() => setActiveTab("all")}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition shrink-0 ${
                activeTab === "all"
                  ? "bg-[#D6451B] text-white shadow-xs"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              All Dues ({INITIAL_PENDING.length})
            </button>
            <button
              onClick={() => setActiveTab("critical")}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition shrink-0 ${
                activeTab === "critical"
                  ? "bg-rose-600 text-white shadow-xs"
                  : "text-rose-600 hover:bg-rose-50"
              }`}
            >
              Overdue &gt; 10 Days (
              {INITIAL_PENDING.filter((s) => s.status === "critical").length})
            </button>
            <button
              onClick={() => setActiveTab("upcoming")}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition shrink-0 ${
                activeTab === "upcoming"
                  ? "bg-amber-600 text-white shadow-xs"
                  : "text-amber-700 hover:bg-amber-50"
              }`}
            >
              Due Soon (
              {INITIAL_PENDING.filter((s) => s.status !== "critical").length})
            </button>
          </div>
        </div>

        {/* Pending Students Table & Responsive Cards */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-xs overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 sm:px-6 py-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Pending Accounts
              </h3>
              <p className="text-xs text-slate-500">
                Showing {filteredStudents.length} student records
              </p>
            </div>
            <button
              onClick={() => {
                alert("Exported pending fees spreadsheet to CSV successfully!");
              }}
              className="flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 transition"
            >
              <FaFileExport className="text-slate-400" />
              <span>Export CSV</span>
            </button>
          </div>

          {filteredStudents.length > 0 ? (
            <>
              {/* Desktop Table View */}
              <div className="hidden lg:block overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 uppercase font-semibold">
                    <tr>
                      <th className="px-6 py-3.5">Student</th>
                      <th className="px-4 py-3.5">Batch</th>
                      <th className="px-4 py-3.5">Total / Paid</th>
                      <th className="px-4 py-3.5">Pending Balance</th>
                      <th className="px-4 py-3.5">Due Date</th>
                      <th className="px-6 py-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredStudents.map((student) => (
                      <tr
                        key={student._id}
                        className="hover:bg-orange-50/40 transition"
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-100 font-bold text-[#D6451B]">
                              {student.name.charAt(0)}
                            </div>
                            <div className="min-w-0">
                              <p className="font-bold text-slate-900 truncate">
                                {student.name}
                              </p>
                              <p className="text-[11px] text-slate-400">
                                {student.rollNo} • {student.phone}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <span className="font-medium text-slate-700">
                            {student.batch}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <span className="text-slate-500">
                            ₹{student.paidAmount.toLocaleString("en-IN")} / ₹
                            {student.totalFee.toLocaleString("en-IN")}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <span className="font-extrabold text-sm text-rose-600">
                            ₹{student.pending.toLocaleString("en-IN")}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <div>
                            <p className="font-medium text-slate-800">
                              {student.dueDate}
                            </p>
                            <span
                              className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                student.overdueDays > 0
                                  ? "bg-rose-100 text-rose-700"
                                  : "bg-emerald-100 text-emerald-700"
                              }`}
                            >
                              {student.overdueDays > 0
                                ? `${student.overdueDays}d overdue`
                                : "Due today"}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleSendReminder(student)}
                              className="flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700 hover:bg-emerald-100 transition"
                              title="Send WhatsApp Reminder"
                            >
                              <FaWhatsapp className="text-sm" />
                              <span>Remind</span>
                            </button>
                            <Link
                              href={`/admin-panel/fees/collect/${student._id}`}
                              className="flex items-center gap-1.5 rounded-xl bg-[#D6451B] px-3 py-1.5 text-xs font-bold text-white hover:bg-[#b93814] transition shadow-xs"
                            >
                              <FaCashRegister className="text-xs" />
                              <span>Collect</span>
                            </Link>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card View */}
              <div className="divide-y divide-slate-100 lg:hidden p-3 space-y-3">
                {filteredStudents.map((student) => (
                  <div
                    key={student._id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-100 font-bold text-[#D6451B] shrink-0">
                          {student.name.charAt(0)}
                        </div>
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900 truncate text-xs sm:text-sm">
                            {student.name}
                          </p>
                          <p className="text-[11px] text-slate-500">
                            {student.rollNo}
                          </p>
                        </div>
                      </div>
                      <span className="font-extrabold text-sm text-rose-600">
                        ₹{student.pending.toLocaleString("en-IN")}
                      </span>
                    </div>

                    <div className="text-xs space-y-1 text-slate-600">
                      <p className="truncate">
                        <strong>Cohort:</strong> {student.batch}
                      </p>
                      <p>
                        <strong>Due Date:</strong> {student.dueDate} (
                        {student.overdueDays}d overdue)
                      </p>
                      <p>
                        <strong>Paid:</strong> ₹
                        {student.paidAmount.toLocaleString("en-IN")} of ₹
                        {student.totalFee.toLocaleString("en-IN")}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-slate-200">
                      <button
                        onClick={() => handleSendReminder(student)}
                        className="flex-1 flex items-center justify-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 py-2 text-xs font-bold text-emerald-700 hover:bg-emerald-100 transition"
                      >
                        <FaWhatsapp />
                        <span>WhatsApp</span>
                      </button>
                      <Link
                        href={`/admin-panel/fees/collect/${student._id}`}
                        className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-[#D6451B] py-2 text-xs font-bold text-white hover:bg-[#b93814] transition"
                      >
                        <FaCashRegister />
                        <span>Collect</span>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs sm:text-sm">
              <FaExclamationCircle className="mx-auto text-3xl text-slate-300 mb-2" />
              No pending dues matching the filter criteria.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
