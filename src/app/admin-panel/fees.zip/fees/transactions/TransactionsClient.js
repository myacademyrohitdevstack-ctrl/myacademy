"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FaReceipt,
  FaSearch,
  FaFilter,
  FaFileExport,
  FaEye,
  FaPrint,
  FaTimes,
  FaMoneyBillWave,
  FaWallet,
  FaCreditCard,
  FaCheckCircle,
  FaQrcode,
  FaUniversity,
} from "react-icons/fa";
import FeesNav from "../components/FeesNav";

const INITIAL_TRANSACTIONS = [
  {
    _id: "tx-001",
    receiptNo: "REC-2026-881",
    studentName: "Kabir Verma",
    rollNo: "IMA-2026-012",
    batch: "Full Stack Web Dev (Batch A)",
    amount: 15000,
    mode: "UPI",
    refNumber: "UPI-8842193",
    date: "2026-10-21 02:45 PM",
    status: "Completed",
    remarks: "Installment #2 via GPay",
  },
  {
    _id: "tx-002",
    receiptNo: "REC-2026-880",
    studentName: "Sneha Reddy",
    rollNo: "IMA-2026-015",
    batch: "Data Science & AI (Morning)",
    amount: 10000,
    mode: "Net Banking",
    refNumber: "NEFT-9912048",
    date: "2026-10-21 11:20 AM",
    status: "Completed",
    remarks: "Monthly fee payment",
  },
  {
    _id: "tx-003",
    receiptNo: "REC-2026-879",
    studentName: "Devansh Nair",
    rollNo: "IMA-2026-005",
    batch: "Python Masterclass (Evening)",
    amount: 7500,
    mode: "Cash",
    refNumber: "CASH-CTR-12",
    date: "2026-10-20 04:15 PM",
    status: "Completed",
    remarks: "Received at reception counter",
  },
  {
    _id: "tx-004",
    receiptNo: "REC-2026-878",
    studentName: "Isha Kapoor",
    rollNo: "IMA-2026-019",
    batch: "UI/UX Design Studio",
    amount: 10000,
    mode: "Card",
    refNumber: "CARD-POS-4481",
    date: "2026-10-20 03:00 PM",
    status: "Completed",
    remarks: "HDFC Debit Card swipe",
  },
  {
    _id: "tx-005",
    receiptNo: "REC-2026-877",
    studentName: "Rohan Mehta",
    rollNo: "IMA-2026-003",
    batch: "Python Masterclass (Evening)",
    amount: 10000,
    mode: "UPI",
    refNumber: "UPI-7719203",
    date: "2026-10-19 01:10 PM",
    status: "Completed",
    remarks: "First installment",
  },
  {
    _id: "tx-006",
    receiptNo: "REC-2026-876",
    studentName: "Aarav Sharma",
    rollNo: "IMA-2026-001",
    batch: "Full Stack Web Dev (Batch A)",
    amount: 22500,
    mode: "UPI",
    refNumber: "UPI-6640192",
    date: "2026-10-18 10:45 AM",
    status: "Completed",
    remarks: "Registration + Term 1 fee",
  },
];

export default function TransactionsClient() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMode, setSelectedMode] = useState("all");
  const [selectedReceipt, setSelectedReceipt] = useState(null);

  const filteredTransactions = INITIAL_TRANSACTIONS.filter((tx) => {
    const matchesSearch =
      tx.receiptNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.rollNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.refNumber.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesMode =
      selectedMode === "all" || tx.mode.toLowerCase() === selectedMode.toLowerCase();

    return matchesSearch && matchesMode;
  });

  const totalCollected = filteredTransactions.reduce(
    (sum, tx) => sum + tx.amount,
    0
  );

  return (
    <div className="w-full min-w-0">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6 px-1 sm:px-6 lg:px-8 w-full min-w-0">
        <FeesNav />

        {/* Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-r from-[#D6451B] to-orange-500 p-4 sm:p-6 lg:p-8 text-white shadow-lg w-full min-w-0"
        >
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between min-w-0">
            <div className="min-w-0 flex-1">
              <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider">
                Financial Audit Log
              </span>

              <h1 className="mt-3 text-2xl font-extrabold sm:text-3xl lg:text-4xl">
                Fee Transactions & Receipts
              </h1>

              <p className="mt-2 text-xs sm:text-sm lg:text-base max-w-2xl text-orange-100 leading-relaxed font-normal">
                Audit complete payment histories, verify reference numbers, view receipts, and export ledger records.
              </p>
            </div>

            <div className="rounded-2xl border border-white/20 bg-white/10 p-4 sm:p-5 backdrop-blur-md shrink-0 lg:w-72">
              <p className="text-xs text-orange-100 font-semibold uppercase tracking-wider">
                Total Inflow (Filtered)
              </p>
              <h2 className="mt-2 text-2xl sm:text-4xl font-extrabold">
                ₹{totalCollected.toLocaleString("en-IN")}
              </h2>
              <p className="mt-1 text-xs text-orange-100">
                {filteredTransactions.length} transaction entries
              </p>
            </div>
          </div>
        </motion.section>

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-2.5 sm:gap-4 lg:grid-cols-4 w-full min-w-0">
          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Today's Total</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-emerald-600">
              ₹42,500
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Across 4 payments</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">UPI / QR Inflows</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-[#D6451B]">
              74%
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Preferred payment mode</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Counter Cash Inflow</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-slate-900">
              26%
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Direct counter receipts</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Success Rate</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-blue-600">
              100%
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Zero chargebacks</p>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
          <div className="relative flex-1 min-w-0">
            <FaSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs" />
            <input
              type="text"
              placeholder="Search by receipt #, student name, roll number, or transaction ref..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-xs sm:text-sm font-medium text-slate-900 outline-none focus:border-[#D6451B]"
            />
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <select
              value={selectedMode}
              onChange={(e) => setSelectedMode(e.target.value)}
              className="rounded-xl border border-slate-200 px-3 py-2.5 text-xs sm:text-sm font-bold text-slate-700 outline-none focus:border-[#D6451B] bg-slate-50"
            >
              <option value="all">All Payment Modes</option>
              <option value="UPI">UPI / QR</option>
              <option value="Cash">Cash Counter</option>
              <option value="Card">Card</option>
              <option value="Net Banking">Net Banking</option>
            </select>

            <button
              onClick={() => {
                alert("Exported full transaction audit logs to CSV!");
              }}
              className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs sm:text-sm font-bold text-slate-700 hover:bg-slate-50 transition"
            >
              <FaFileExport className="text-slate-400" />
              <span>Export</span>
            </button>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-xs overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 sm:px-6 py-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Recorded Transactions
              </h3>
              <p className="text-xs text-slate-500">
                Showing {filteredTransactions.length} receipts
              </p>
            </div>
          </div>

          {filteredTransactions.length > 0 ? (
            <>
              {/* Desktop Table View */}
              <div className="hidden lg:block overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 uppercase font-semibold">
                    <tr>
                      <th className="px-6 py-3.5">Receipt #</th>
                      <th className="px-4 py-3.5">Date & Time</th>
                      <th className="px-4 py-3.5">Student</th>
                      <th className="px-4 py-3.5">Batch</th>
                      <th className="px-4 py-3.5">Mode & Ref</th>
                      <th className="px-4 py-3.5">Amount</th>
                      <th className="px-6 py-3.5 text-right">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredTransactions.map((tx) => (
                      <tr key={tx._id} className="hover:bg-orange-50/40 transition">
                        <td className="px-6 py-4">
                          <span className="font-extrabold text-slate-900">
                            {tx.receiptNo}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-slate-600">
                          {tx.date}
                        </td>
                        <td className="px-4 py-4">
                          <div>
                            <p className="font-bold text-slate-900">
                              {tx.studentName}
                            </p>
                            <p className="text-[11px] text-slate-400">
                              {tx.rollNo}
                            </p>
                          </div>
                        </td>
                        <td className="px-4 py-4 text-slate-700">
                          {tx.batch}
                        </td>
                        <td className="px-4 py-4">
                          <div>
                            <span className="inline-block rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700">
                              {tx.mode}
                            </span>
                            <p className="text-[10px] text-slate-400 mt-0.5">
                              {tx.refNumber}
                            </p>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <span className="font-extrabold text-sm text-emerald-600">
                            ₹{tx.amount.toLocaleString("en-IN")}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => setSelectedReceipt(tx)}
                            className="inline-flex items-center gap-1.5 rounded-xl bg-orange-50 px-3 py-1.5 text-xs font-bold text-[#D6451B] hover:bg-orange-100 transition"
                          >
                            <FaEye className="text-xs" />
                            <span>View</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card View */}
              <div className="divide-y divide-slate-100 lg:hidden p-3 space-y-3">
                {filteredTransactions.map((tx) => (
                  <div
                    key={tx._id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2.5"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-extrabold text-slate-900 text-xs">
                          {tx.receiptNo}
                        </span>
                        <p className="font-bold text-slate-900 text-sm mt-0.5">
                          {tx.studentName}
                        </p>
                      </div>
                      <span className="font-extrabold text-base text-emerald-600">
                        +₹{tx.amount.toLocaleString("en-IN")}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 space-y-0.5">
                      <p className="truncate">
                        <strong>Cohort:</strong> {tx.batch}
                      </p>
                      <p>
                        <strong>Mode:</strong> {tx.mode} ({tx.refNumber})
                      </p>
                      <p className="text-[11px] text-slate-400">
                        {tx.date}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-200 flex justify-end">
                      <button
                        onClick={() => setSelectedReceipt(tx)}
                        className="flex items-center gap-1.5 rounded-xl bg-orange-50 px-3 py-1.5 text-xs font-bold text-[#D6451B] hover:bg-orange-100 transition"
                      >
                        <FaEye className="text-xs" />
                        <span>View Receipt</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs sm:text-sm">
              No transactions found matching your search.
            </div>
          )}
        </div>

        {/* View Receipt Modal */}
        <AnimatePresence>
          {selectedReceipt && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full max-w-lg rounded-2xl sm:rounded-3xl bg-white p-5 sm:p-7 shadow-2xl border border-slate-200"
              >
                <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#D6451B] to-orange-500 text-white font-extrabold shadow-xs">
                      MA
                    </div>
                    <div>
                      <h3 className="font-extrabold text-base text-slate-900">
                        MyAcademy
                      </h3>
                      <p className="text-[10px] font-bold tracking-wider text-[#D6451B] uppercase">
                        Official Payment Receipt
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedReceipt(null)}
                    className="rounded-xl p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                  >
                    <FaTimes />
                  </button>
                </div>

                <div className="mt-5 space-y-3 rounded-xl bg-slate-50 p-4 border border-slate-100 text-xs">
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Receipt Number:</span>
                    <strong className="font-bold text-slate-900">
                      {selectedReceipt.receiptNo}
                    </strong>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Transaction Date:</span>
                    <span className="font-medium text-slate-700">
                      {selectedReceipt.date}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Student:</span>
                    <strong className="font-bold text-slate-900">
                      {selectedReceipt.studentName} ({selectedReceipt.rollNo})
                    </strong>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Batch Cohort:</span>
                    <span className="font-medium text-slate-700">
                      {selectedReceipt.batch}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Payment Mode:</span>
                    <span className="font-bold text-slate-800">
                      {selectedReceipt.mode} ({selectedReceipt.refNumber})
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Status:</span>
                    <span className="font-bold text-emerald-600">
                      {selectedReceipt.status}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200/60 pb-2">
                    <span className="text-slate-500">Notes:</span>
                    <span className="font-medium text-slate-700">
                      {selectedReceipt.remarks}
                    </span>
                  </div>
                  <div className="flex justify-between pt-1 text-sm font-extrabold">
                    <span className="text-slate-900">Amount Received:</span>
                    <span className="text-emerald-600 text-base">
                      ₹{selectedReceipt.amount.toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>

                <p className="mt-4 text-center text-[10px] text-slate-400">
                  Certified payment receipt issued via MyAcademy Finance Ledger.
                </p>

                <div className="mt-5 flex gap-2.5">
                  <button
                    onClick={() => window.print()}
                    className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-slate-900 py-3 text-xs sm:text-sm font-bold text-white hover:bg-slate-800 transition"
                  >
                    <FaPrint />
                    <span>Print Receipt</span>
                  </button>
                  <button
                    onClick={() => setSelectedReceipt(null)}
                    className="flex items-center justify-center px-4 rounded-xl border border-slate-200 text-xs sm:text-sm font-bold text-slate-700 hover:bg-slate-50 transition"
                  >
                    Close
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
