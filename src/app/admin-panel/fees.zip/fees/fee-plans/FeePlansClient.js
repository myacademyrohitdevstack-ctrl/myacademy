"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FaFileInvoiceDollar,
  FaPlus,
  FaUsers,
  FaLayerGroup,
  FaCalendarAlt,
  FaCheckCircle,
  FaEdit,
  FaTrash,
  FaTimes,
  FaMoneyBillWave,
  FaTag,
} from "react-icons/fa";
import FeesNav from "../components/FeesNav";

const INITIAL_PLANS = [
  {
    _id: "plan-1",
    name: "Full Stack Web Development - 3 Installments",
    batch: "Full Stack Web Dev (Batch A)",
    totalAmount: 35000,
    frequency: "Monthly",
    installments: 3,
    installmentAmount: 11667,
    lateFee: 250,
    assignedStudents: 48,
    status: "Active",
  },
  {
    _id: "plan-2",
    name: "Data Science & AI - Comprehensive Plan",
    batch: "Data Science & AI (Morning)",
    totalAmount: 40000,
    frequency: "Monthly",
    installments: 4,
    installmentAmount: 10000,
    lateFee: 300,
    assignedStudents: 52,
    status: "Active",
  },
  {
    _id: "plan-3",
    name: "Python Fast-Track - One-Time Payment",
    batch: "Python Masterclass (Evening)",
    totalAmount: 22000,
    frequency: "One-Time (Lumpsum)",
    installments: 1,
    installmentAmount: 22000,
    lateFee: 0,
    assignedStudents: 36,
    status: "Active",
  },
  {
    _id: "plan-4",
    name: "UI/UX Design Studio - Bi-Monthly",
    batch: "UI/UX Design Studio",
    totalAmount: 28000,
    frequency: "Bi-Monthly",
    installments: 2,
    installmentAmount: 14000,
    lateFee: 200,
    assignedStudents: 30,
    status: "Active",
  },
  {
    _id: "plan-5",
    name: "Foundation Cohort - Monthly Plan",
    batch: "Foundation Batch",
    totalAmount: 18000,
    frequency: "Monthly",
    installments: 3,
    installmentAmount: 6000,
    lateFee: 150,
    assignedStudents: 18,
    status: "Active",
  },
];

export default function FeePlansClient() {
  const [plans, setPlans] = useState(INITIAL_PLANS);
  const [modalOpen, setModalOpen] = useState(false);
  const [newPlan, setNewPlan] = useState({
    name: "",
    batch: "Full Stack Web Dev (Batch A)",
    totalAmount: 30000,
    frequency: "Monthly",
    installments: 3,
    lateFee: 200,
  });

  const handleCreatePlan = (e) => {
    e.preventDefault();
    const instCount = Math.max(1, Number(newPlan.installments));
    const instAmt = Math.round(Number(newPlan.totalAmount) / instCount);
    const created = {
      _id: `plan-${Date.now()}`,
      name: newPlan.name,
      batch: newPlan.batch,
      totalAmount: Number(newPlan.totalAmount),
      frequency: newPlan.frequency,
      installments: instCount,
      installmentAmount: instAmt,
      lateFee: Number(newPlan.lateFee),
      assignedStudents: 0,
      status: "Active",
    };
    setPlans([created, ...plans]);
    setModalOpen(false);
    setNewPlan({
      name: "",
      batch: "Full Stack Web Dev (Batch A)",
      totalAmount: 30000,
      frequency: "Monthly",
      installments: 3,
      lateFee: 200,
    });
  };

  const handleDelete = (id) => {
    if (confirm("Are you sure you want to delete this fee structure?")) {
      setPlans(plans.filter((p) => p._id !== id));
    }
  };

  const totalAssigned = plans.reduce((sum, p) => sum + p.assignedStudents, 0);

  return (
    <div className="w-full min-w-0">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6 px-1 sm:px-6 lg:px-8 w-full min-w-0">
        <FeesNav />

        {/* Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-r from-[#D6451B] to-orange-500 p-4 sm:p-6 lg:p-8 text-white shadow-lg w-full min-w-0"
        >
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between min-w-0">
            <div className="min-w-0 flex-1">
              <span className="rounded-full bg-white/20 px-3 py-1 text-xs font-semibold uppercase tracking-wider">
                Fee Plan Configuration
              </span>

              <h1 className="mt-3 text-2xl font-extrabold sm:text-3xl lg:text-4xl">
                Fee Structures & Plans
              </h1>

              <p className="mt-2 text-xs sm:text-sm lg:text-base max-w-2xl text-orange-100 leading-relaxed font-normal">
                Define batch fee templates, installment timetables, admission dues, and automated late penalty rules.
              </p>
            </div>

            <button
              onClick={() => setModalOpen(true)}
              className="flex items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-xs sm:text-sm font-bold text-[#D6451B] shadow-xs hover:bg-orange-50 transition shrink-0"
            >
              <FaPlus className="text-xs" />
              <span>Create Fee Structure</span>
            </button>
          </div>
        </motion.section>

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-2.5 sm:gap-4 lg:grid-cols-4 w-full min-w-0">
          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Active Plans</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-slate-900">
              {plans.length}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Template structures</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Enrolled Students</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-[#D6451B]">
              {totalAssigned}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Assigned to active plans</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Average Plan Value</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-emerald-600">
              ₹{(
                plans.reduce((sum, p) => sum + p.totalAmount, 0) / (plans.length || 1)
              ).toFixed(0)}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Across all cohorts</p>
          </div>

          <div className="rounded-xl sm:rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 shadow-xs">
            <p className="text-xs font-semibold text-slate-500">Payment Modes Supported</p>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold text-blue-600">
              UPI & Cash
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">+ Cards & Net Banking</p>
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid gap-4 sm:gap-6 md:grid-cols-2 xl:grid-cols-3 w-full min-w-0">
          {plans.map((plan) => (
            <div
              key={plan._id}
              className="rounded-2xl sm:rounded-3xl border border-slate-200 bg-white p-4 sm:p-5 shadow-xs flex flex-col justify-between hover:shadow-md transition w-full min-w-0"
            >
              <div>
                <div className="flex items-start justify-between gap-2.5">
                  <div className="min-w-0 flex-1">
                    <h3 className="text-base font-bold text-slate-900 truncate">
                      {plan.name}
                    </h3>
                    <p className="text-xs text-slate-500 truncate mt-0.5">
                      Batch: {plan.batch}
                    </p>
                  </div>
                  <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-bold text-emerald-700 shrink-0">
                    {plan.status}
                  </span>
                </div>

                {/* Amount Highlight */}
                <div className="mt-4 rounded-xl bg-orange-50/60 p-3 border border-orange-100">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    Total Structure Fee
                  </p>
                  <h4 className="mt-0.5 text-xl font-extrabold text-[#D6451B]">
                    ₹{plan.totalAmount.toLocaleString("en-IN")}
                  </h4>
                  <p className="text-[11px] text-slate-600 mt-1">
                    {plan.installments > 1
                      ? `${plan.installments} installments of ₹${plan.installmentAmount.toLocaleString(
                          "en-IN"
                        )} / ${plan.frequency}`
                      : "Full one-time lump-sum"}
                  </p>
                </div>

                {/* Features List */}
                <div className="mt-4 space-y-2 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-medium">Frequency:</span>
                    <strong className="text-slate-800">{plan.frequency}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-medium">Late Penalty:</span>
                    <strong className="text-rose-600">
                      {plan.lateFee > 0 ? `₹${plan.lateFee} / week` : "None"}
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-medium">Assigned Students:</span>
                    <strong className="text-slate-800">
                      {plan.assignedStudents} enrolled
                    </strong>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => alert(`Editing plan: ${plan.name}`)}
                  className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-slate-100 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 transition"
                >
                  <FaEdit className="text-xs" />
                  <span>Configure</span>
                </button>
                <button
                  onClick={() => handleDelete(plan._id)}
                  className="p-2.5 rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100 transition"
                  title="Delete Fee Structure"
                >
                  <FaTrash className="text-xs" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Create Plan Modal */}
        <AnimatePresence>
          {modalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full max-w-lg rounded-2xl sm:rounded-3xl bg-white p-5 sm:p-7 shadow-2xl border border-slate-200"
              >
                <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#D6451B] to-orange-500 text-white font-extrabold shadow-xs">
                      <FaPlus />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-base text-slate-900">
                        Create Fee Structure
                      </h3>
                      <p className="text-xs text-slate-500">
                        Add a new pricing tier and installment plan
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setModalOpen(false)}
                    className="rounded-xl p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                  >
                    <FaTimes />
                  </button>
                </div>

                <form onSubmit={handleCreatePlan} className="mt-5 space-y-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Plan Title *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Masterclass 4-Month Installment Plan"
                      value={newPlan.name}
                      onChange={(e) =>
                        setNewPlan({ ...newPlan, name: e.target.value })
                      }
                      className="w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-medium outline-none focus:border-[#D6451B]"
                    />
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Batch Cohort
                      </label>
                      <select
                        value={newPlan.batch}
                        onChange={(e) =>
                          setNewPlan({ ...newPlan, batch: e.target.value })
                        }
                        className="w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-bold bg-slate-50 outline-none focus:border-[#D6451B]"
                      >
                        <option>Full Stack Web Dev (Batch A)</option>
                        <option>Data Science & AI (Morning)</option>
                        <option>Python Masterclass (Evening)</option>
                        <option>UI/UX Design Studio</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Total Fee Amount (₹) *
                      </label>
                      <input
                        type="number"
                        min="1000"
                        required
                        value={newPlan.totalAmount}
                        onChange={(e) =>
                          setNewPlan({
                            ...newPlan,
                            totalAmount: Number(e.target.value),
                          })
                        }
                        className="w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-bold outline-none focus:border-[#D6451B]"
                      />
                    </div>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-3">
                    <div>
                      <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Frequency
                      </label>
                      <select
                        value={newPlan.frequency}
                        onChange={(e) =>
                          setNewPlan({ ...newPlan, frequency: e.target.value })
                        }
                        className="w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-bold bg-slate-50 outline-none focus:border-[#D6451B]"
                      >
                        <option>Monthly</option>
                        <option>Bi-Monthly</option>
                        <option>Quarterly</option>
                        <option>One-Time</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Installments
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="12"
                        value={newPlan.installments}
                        onChange={(e) =>
                          setNewPlan({
                            ...newPlan,
                            installments: Number(e.target.value),
                          })
                        }
                        className="w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-bold outline-none focus:border-[#D6451B]"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Late Fine / Wk (₹)
                      </label>
                      <input
                        type="number"
                        min="0"
                        value={newPlan.lateFee}
                        onChange={(e) =>
                          setNewPlan({
                            ...newPlan,
                            lateFee: Number(e.target.value),
                          })
                        }
                        className="w-full rounded-xl border border-slate-200 p-3 text-xs sm:text-sm font-bold outline-none focus:border-[#D6451B]"
                      />
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex gap-2">
                    <button
                      type="submit"
                      className="flex-1 rounded-xl bg-[#D6451B] py-3 text-xs sm:text-sm font-bold text-white hover:bg-[#b93814] transition shadow-xs"
                    >
                      Save Structure
                    </button>
                    <button
                      type="button"
                      onClick={() => setModalOpen(false)}
                      className="px-4 rounded-xl border border-slate-200 text-xs sm:text-sm font-bold text-slate-700 hover:bg-slate-50"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
